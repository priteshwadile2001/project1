# AspNetWebFormsApp
#Azure #appservice | ASP.NET C# Web App application website #deployment
How to deploy ASP.NET Web Forms / MVC / Core application to Azure from #visualstudio

This is a sample asp.net webforms application that can be used with Azure App Service | Web App with visual studio.
A beautiful login page design is added with the help of HTML, CSS, BOOTSTRAP. 
Login Template with server side code is also available to validate the user authentication.

Suggested Video: 
Azure App Service | Web Apps | GitHub Repo | Website Deployment | Hosting
https://youtu.be/mpSeDeAU4Cw
